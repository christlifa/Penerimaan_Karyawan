<?php 
/**	
 * Perameter Model
 *
 * @author Lifa Christian <LifaChristian2@gmail.com>
 * November 2018
 */
use core\Model;
class Penilaian_model extends Model 
{
	/**
	 * Variable tabel
	 */
	var $tableKaryawan = 'karyawan';
	var $tablePenilaian = 'Penilaian';
	var $tableParameter = 'globalparameter';

	public function __construct()
	{
		parent::__construct();
	}

	public function getData(){

		$sql = $this->db;

		$sql->select('kar.*,par.Parameter as JenisKelamin');
		$sql->from($this->tableKaryawan.' kar');
		$sql->join($this->tableParameter.' par', 'par.Gbid = kar.Jk', 'inner');
		$get = $sql->get();

		return $get;
	}

	public function getDataVal($Id,$combine){

		$sql = $this->db;

		$sql->select('*');
		$sql->from($this->tablePenilaian);
		$sql->where('KaryawanId',$Id);
		$sql->where('Code',$combine);
		$get = $sql->get();

		return $get;
	}

	public function saveData($data){
		return $this->db->insert($this->tablePenilaian, $data);
	}

	public function getDataPrint($date1,$Id){
		$sql = $this->db;

		$sql->select('PN.*,KR.NamaKaryawan as NamaKaryawan');
		$sql->from($this->tablePenilaian.' PN');
		$sql->join($this->tableKaryawan.' KR', 'PN.KaryawanId = KR.KaryawanId', 'inner');

		$sql->where('PN.TanggalPenilaian', $date1);
		$sql->where('PN.KaryawanId', $Id);
		
		$get = $sql->get();

		return $get;
	}

}	

?>