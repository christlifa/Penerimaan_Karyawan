<?php 
/**	
 * Perameter Model
 *
 * @author Lifa Christian <LifaChristian2@gmail.com>
 * November 2018
 */
use core\Model;
class Parameter_model extends Model 
{
	/**
	 * Variable tabel
	 */
	var $tableParameter = 'globalparameter';
	public function __construct()
	{
		parent::__construct();
	}

	public function getDataJK(){

		$sql = $this->db;

		$sql->select('*');
		$sql->from($this->tableParameter);
		$sql->where('Code',1);
		$get = $sql->get();

		return $get;
	}
	
}

?>