<?php 
/**	
 * Perameter Model
 *
 * @author Lifa Christian <LifaChristian2@gmail.com>
 * November 2018
 */
use core\Model;
class Karyawan_model extends Model 
{
	/**
	 * Variable tabel
	 */
	var $tableKaryawan = 'karyawan';
	var $tableParameter = 'globalparameter';
	var $tablePenilaian = 'penilaian';
	public function __construct()
	{
		parent::__construct();
	}

	public function getData(){

		$sql = $this->db;

		$sql->select('kar.*,par.Parameter as JenisKelamin');
		$sql->from($this->tableKaryawan.' kar');
		$sql->join($this->tableParameter.' par', 'par.Gbid = kar.Jk', 'inner');
		$get = $sql->get();

		return $get;
	}


	public function saveData($data){
		return $this->db->insert($this->tableKaryawan, $data);
	}
	
	public function deleteData($id){
		$this->db->where('KaryawanId', $id);
		return $this->db->delete($this->tableKaryawan);
	}

	public function updateData($flagforupdate, $data_save){
		$this->db->where('KaryawanId', $flagforupdate);

		return $this->db->update($this->tableKaryawan, $data_save);
	}

	public function getDataDashboard(){

		$sql = $this->db;

		$sql->select('kar.*,pen.NilaiWaktuDatang as NilaiWaktuDatang , pen.NilaiWaktuPulang as NilaiWaktuPulang , pen.NilaiWaktuTugas as NilaiWaktuTugas , pen.NilaiPekerjaanTpt as NilaiPekerjaanTpt, pen.NilaiPekerjaanTptDt as NilaiPekerjaanTptDt, pen.NilaiKerjasamaTeam as NilaiKerjasamaTeam, pen.NilaiKerjaIndividu as NilaiKerjaIndividu, pen.NilaiAbsen as NilaiAbsen,
		');
		$sql->from($this->tableKaryawan.' kar');
		$sql->join($this->tablePenilaian.' pen', 'pen.KaryawanId = kar.KaryawanId', 'left');
		$get = $sql->get();

		return $get;
	}

}

?>