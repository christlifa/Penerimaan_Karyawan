<?php
class App_auth 
{
	public function index()
	{
	}
}
?>