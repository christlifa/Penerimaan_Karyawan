<?php
/**	
 * 
 * @author Lifa Christian <LifaChristian2@gmail.com>
 * November 2018
 */
use libraries\BaseController;
class Penilaian extends BaseController 
{
	/**
	 * Construcktor CodeIgniter
	 */
	public function __construct()
	{
		parent::__construct();

		$this->auth->check_auth();
		// load model
		$this->load->model('Penilaian_model');
	}


	public function index(){

		$data['content_title'] = 'Penilaian';
		$this->twiggy_display('adm/Penilaian/index', $data);
	}



	public function getData($combine){

			$data = [];
			$get_data = $this->Penilaian_model->getData()->result();

			// ketika data tersedia
			// maka generate data json untuk Datatable
			if($get_data)
			{
				$no = 1;
				foreach($get_data as $get_row)
				{
					$data[] = array(
						'no'                => $no,
						'KaryawanId'    	=> $get_row->KaryawanId,
						'NamaKaryawan'    	=> $get_row->NamaKaryawan,
						'Jk'				=> $get_row->Jk,
						'JenisKelamin'		=> $get_row->JenisKelamin,
						'Alamat'			=> $get_row->Alamat,
						'DataPenilaian'		=> $this->Penilaian_model->getDataVal($get_row->KaryawanId,$combine)->result()
					);
					$no++;
				}
			}

			$response = [
	            'data'         => $data,
	            'recordsTotal' => count($data)
	        ];
	        // print_r($response);
	        output_json($response['data']);
	}

	public function saveData(){
	    $dataFromFe = (array)json_decode(file_get_contents('php://input'));
	    $dataFinal = array(
	        'KaryawanId'     		=> $dataFromFe['KaryawanId'],
	        'NilaiWaktuDatang'     	=> $dataFromFe['NilaiWaktuDatang'],
	        'NilaiWaktuPulang'     	=> $dataFromFe['NilaiWaktuPulang'],
	        'NilaiWaktuTugas'  		=> $dataFromFe['NilaiWaktuTugas'],
	        'NilaiPekerjaanTpt'    	=> $dataFromFe['NilaiPekerjaanTpt'],
	        'NilaiPekerjaanTptDt'   => $dataFromFe['NilaiPekerjaanTptDt'],
	        'NilaiKerjasamaTeam'	=> $dataFromFe['NilaiKerjasamaTeam'],
	        'NilaiKerjaIndividu'	=> $dataFromFe['NilaiKerjaIndividu'],
	        'JumlahAlva'			=> $dataFromFe['JumlahAlva'],
	        'JumlahIzin'			=> $dataFromFe['JumlahIzin'],
	        'JumlahSakit'			=> $dataFromFe['JumlahSakit'],
	        'NilaiAbsen'			=> $dataFromFe['NilaiAbsen'],
	        'TanggalPenilaian'		=> date('Y-m-d'),
	        'WaktuPenilaian'		=> date('H:i:s'),
	        'Code'					=> $dataFromFe['Code']
	    );
	    if($dataFinal){
	        $save = $this->Penilaian_model->saveData($dataFinal);      
	    }
	}


	public function printLaporan($yearFirst,$monthFirst,$dayFirst,$KaryawanId)
	{
		// $dataId
		// echo $dataId;
		
		$data['content_title'] = 'Print Laporan Barang Kembali';
		
		$data['yearFirst'] = $yearFirst;
		$data['monthFirst'] = $monthFirst;
		$data['dayFirst'] = $dayFirst;
		
		$data['KaryawanId'] = $KaryawanId;
		// $data['id'] = $dataId;
		// $data['mejaNO'] = $mejaNo;
		// $data['isPrint'] = 1;
		$this->twiggy_display('adm/Penilaian/printLaporan', $data);

		// $this->getDataResep($dataId);
	}


	public function getDataFilter($date1,$Id){
			$data = [];
			$get_data = $this->Penilaian_model->getDataPrint($date1,$Id)->result();

			// ketika data tersedia
			// maka generate data json untuk Datatable
			if($get_data)
			{
				$no = 1;
				foreach($get_data as $get_row)
				{
					$data[] = array(
						'no'             	   			=> $no,
						'NamaKaryawan'			   		=> $get_row->NamaKaryawan,
						'PenilaianId'					=> $get_row->PenilaianId,
						'TanggalPenilaian'				=> $get_row->TanggalPenilaian,
						'WaktuPenilaian'				=> $get_row->WaktuPenilaian,
						'NilaiWaktuDatang'				=> $get_row->NilaiWaktuDatang,
						'NilaiWaktuPulang'				=> $get_row->NilaiWaktuPulang,
						'NilaiWaktuTugas'				=> $get_row->NilaiWaktuTugas,
						'NilaiPekerjaanTpt'				=> $get_row->NilaiPekerjaanTpt,
						'NilaiPekerjaanTptDt'			=> $get_row->NilaiPekerjaanTptDt,
						'NilaiKerjasamaTeam'			=> $get_row->NilaiKerjasamaTeam,
						'NilaiKerjaIndividu'			=> $get_row->NilaiKerjaIndividu,
						'JumlahAlva'					=> intval($get_row->JumlahAlva),
						'JumlahIzin'					=> intval($get_row->JumlahIzin),
						'JumlahSakit'					=> intval($get_row->JumlahSakit),
						'NilaiAbsen'					=> $get_row->NilaiAbsen,

					);
					$no++;
				}
			}

			$response = [
	            'data'         => $data,
	            'recordsTotal' => count($data)
	        ];
	        // print_r($response);
	        output_json($response['data']);
	}

}
?>