<?php
/**	
 * 
 * @author Lifa Christian <LifaChristian2@gmail.com>
 * November 2018
 */
use libraries\BaseController;
class Karyawan extends BaseController 
{
	/**
	 * Construcktor CodeIgniter
	 */
	public function __construct()
	{
		parent::__construct();

		$this->auth->check_auth();
		// load model
		$this->load->model('Master/Karyawan/Karyawan_model');
	}

	public function index(){

		$data['content_title'] = 'Karyawan';
		$this->twiggy_display('adm/Master/Karyawan/index', $data);
	}

	public function getData(){

			$data = [];
			$get_data = $this->Karyawan_model->getData()->result();

			// ketika data tersedia
			// maka generate data json untuk Datatable
			if($get_data)
			{
				$no = 1;
				foreach($get_data as $get_row)
				{
					$data[] = array(
						'no'                => $no,
						'KaryawanId'    	=> $get_row->KaryawanId,
						'NamaKaryawan'    	=> $get_row->NamaKaryawan,
						'Jk'				=> $get_row->Jk,
						'JenisKelamin'		=> $get_row->JenisKelamin,
						'Alamat'			=> $get_row->Alamat
					);
					$no++;
				}
			}

			$response = [
	            'data'         => $data,
	            'recordsTotal' => count($data)
	        ];
	        // print_r($response);
	        output_json($response['data']);
	}


	public function saveData(){
		$dataFromFe = (array)json_decode(file_get_contents('php://input'));
		$dataFinal = array(
		    'NamaKaryawan'	=> $dataFromFe['NamaKaryawan'],
		    'Jk'			=> $dataFromFe['Jk'],
		    'Alamat'		=> $dataFromFe['Alamat'],
		    	
		);
		if($dataFinal){
			$save = $this->Karyawan_model->saveData($dataFinal);		
		}
	}


	public function deleteData(){
		$dataFromFe = (array)json_decode(file_get_contents('php://input'));
		$dataDelete = $dataFromFe;
		foreach($dataDelete as $row)
		{
			$delete_type = $this->Karyawan_model->deleteData($row);
		}
	}
	
	public function updateData(){
		$dataFromFe = (array)json_decode(file_get_contents('php://input'));
		$id = $dataFromFe['KaryawanId'];
		$dataFinal = array(
		    'NamaKaryawan'	=> $dataFromFe['NamaKaryawan'],
		    'Jk'			=> $dataFromFe['Jk'],
		    'Alamat'		=> $dataFromFe['Alamat'],
		);

		if($dataFinal){
			$save = $this->Karyawan_model->updateData($id,$dataFinal);		
		}
	}


	public function getDataDashboard(){

			$data = [];
			$get_data = $this->Karyawan_model->getDataDashboard()->result();

			// ketika data tersedia
			// maka generate data json untuk Datatable
			if($get_data)
			{
				$no = 1;
				foreach($get_data as $get_row)
				{
					$data[] = array(
						'no'                => $no,
						'KaryawanId'    	=> $get_row->KaryawanId,
						'NamaKaryawan'    	=> $get_row->NamaKaryawan,
						'Jk'				=> $get_row->Jk,
						// 'JenisKelamin'		=> $get_row->JenisKelamin,
						'Alamat'			=> $get_row->Alamat,
						'NilaiAbsen'		=> $get_row->NilaiAbsen,
						'NilaiKerjaIndividu'		=> $get_row->NilaiKerjaIndividu,
						'NilaiKerjasamaTeam'		=> $get_row->NilaiKerjasamaTeam,
						'NilaiPekerjaanTptDt'		=> $get_row->NilaiPekerjaanTptDt,
						'NilaiPekerjaanTpt'		=> $get_row->NilaiPekerjaanTpt,
						'NilaiWaktuTugas'		=> $get_row->NilaiWaktuTugas,
						'NilaiWaktuPulang'		=> $get_row->NilaiWaktuPulang,
						'NilaiWaktuDatang'		=> $get_row->NilaiWaktuDatang,
						'Total'					=> $get_row->NilaiAbsen +  $get_row->NilaiKerjaIndividu + $get_row->NilaiKerjasamaTeam + $get_row->NilaiPekerjaanTptDt + $get_row->NilaiPekerjaanTpt + $get_row->NilaiWaktuTugas + $get_row->NilaiWaktuPulang + $get_row->NilaiWaktuDatang + 20
						);
					$no++;
				}
			}

			$response = [
	            'data'         => $data,
	            'recordsTotal' => count($data)
	        ];
	        // print_r($response);
	        output_json($response['data']);
	}
}
?>