<?php
/**
 * @author Hikmahtiar <hikmahtiar.cool@gmail.com>
 */
class Loginweb extends CI_Controller 
{
	/**
	 * Constructor Codeigniter
	 */
	public function __construct()
	{
		parent::__construct();

		$this->load->model('login_model');
	}

	/**
	 * Halaman Index
	 */
	public function index()
	{
		$this->load->view('login/index');
	}

	/**
	 * Proses Login
	 */
	public function proses_login()
	{
		$usernama = $this->input->post('usernama');
		$sandi = $this->input->post('sandi');
		// echo($sandi);
		// $outletId = $this->input->post('OutletId');
		// echo($outletId);
		// echo "$outletId ";

		$login = $this->login_model->get_data_advance($usernama, $sandi)->row();

		if ($login)
		{
			$session = array(
				'user_id'  => $login->LoginId
			);

			$this->session->set_userdata($session);

			redirect('adm/Dashboard');	
		}
		else
		{
			$message = "Username atau password tidak sesuai, silahkan login kembali.";

			$this->session->set_flashdata('notifikasi_login', $message);

			$this->index();
		}
	}
}
?>