var app = angular.module('app', ['angular-loading-bar']);
app.controller('dashboardController', function($scope, $http, dashboardFactory){
	console.log("this dashboard running well");
	$scope.mData = {};

	var a = new Date();
	var yearFirst = a.getFullYear();
	var monthFirst = a.getMonth() + 1;
	var dayFirst = a.getDate();
	var nih;
	if(monthFirst == 1){
		nih = 'Januari';
	}else if(monthFirst == 2){
		nih = 'Febuari';
	}else if(monthFirst == 3){
		nih = 'Maret';
	}else if(monthFirst == 4){
		nih = 'April';
	}else if(monthFirst == 5){
		nih = 'May';
	}else if(monthFirst == 6){
		nih = 'Juni';
	}else if(monthFirst == 7){
		nih = 'Juli';
	}else if(monthFirst == 8){
		nih = 'Agustus';
	}else if(monthFirst == 9){
		nih = 'September';
	}else if(monthFirst == 10){

		nih = 'Oktober';
	}else if(monthFirst == 11){

		nih = 'November';
	}else if(monthFirst == 12){

		nih = 'Desember';
	}else{
		console.log("LC HERE !!!");
	}
	$scope.combine = nih +' '+yearFirst; 

	dashboardFactory.getDataJK().then(function(res) {
			console.log("Data",res.data);
	    },
	    function(err) {
	        console.log("err=>", err);
	    }
	);

	dashboardFactory.getDataDashboard().then(function(res) {
			console.log("Data dashboard",res.data);
			$scope.dataDash = res.data;
	    },
	    function(err) {
	        console.log("err=>", err);
	    }
	);	
});