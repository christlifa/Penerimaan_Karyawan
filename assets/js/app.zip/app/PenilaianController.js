var app = angular.module('app', ['ui.grid', 'ui.grid.pagination','angular-loading-bar']);
app.controller('PenilaianController', function($scope, $http, Penilaianfactory, KaryawanFactory){
	console.log("this penilaian running well");
	$scope.mData = {};
	$scope.mainGrid = true;
	$scope.detailForm = false;
	var combine;
	$scope.getData = function(){
		var a = new Date();
		var yearFirst = a.getFullYear();
		var monthFirst = a.getMonth() + 1;
		var dayFirst = a.getDate();

		console.log("yearFirst",yearFirst);
		console.log("monthFirst",monthFirst);
		combine = yearFirst+''+monthFirst; 
		console.log("combine",combine);
		
		Penilaianfactory.getDataKaryawan(combine).then(function(res) {
				console.log("Data Karyawan",res.data);
				var data = [];
				for(var i = 0; i < res.data.length; i++){
					if(res.data[i].DataPenilaian.length == 0){
						data.push(res.data[i]);
					}
				}
				$scope.gridOptions1.data = data;
		    },
		    function(err) {
		        console.log("err=>", err);
		    }
		);
	}

	var actionButton = '<div class="ui-grid-cell-contents">\
	<a href="#"><i class="fa fa-book" title="Edit" ng-click="grid.appScope.goPen(row.entity)"></i></a>\
	</div>';

	

	$scope.gridOptions1 = {
	  paginationPageSizes: [25, 50, 75],
	  paginationPageSize: 25,
	  enableFiltering: true,
	  enableSorting: true,
	  columnDefs: [
	    { name: 'Nama',field:'NamaKaryawan'},
	    // { name: 'Jenis Kelamin',field:'JenisKelamin'},
	    // { name: 'Alamat',field:'Alamat'},
	    { name: 'Action', cellTemplate: actionButton,  enableFiltering: false}
	  ]
	};

	var DataSave = [];
	$scope.goPen = function(Data){
		DataSave.push({
			WaktuDatang : 0,
			WaktuPulang : 0,
			WaktuTugas : 0,
			KemampuanMenPek : 0,
			KemampuanMenPekDT : 0,
			KemampuanBS : 0,
			KemampuanBT : 0
		});

		$scope.mData.JumAlpa = 0;
		$scope.mData.JumIzin = 0;
		$scope.mData.JumSakit = 0;
		console.log("Data penilaian", Data);
		$scope.dataKaryawan = Data;
		$scope.mainGrid = false;
		$scope.detailForm = true;

		$scope.formWaktu = true;
		$scope.formKemampuan = false;
		$scope.formAbsensi = false;
	}
	
	$scope.kembaliButton = function(){
		$scope.mData = {};
		DataSave = [];
		$scope.mainGrid = true;
		$scope.detailForm = false;
	}

	$scope.nextButton = function(Id){
		if(Id == 1){

			$scope.formWaktu = false;
			$scope.formKemampuan = true;
			$scope.formAbsensi = false;
		}else if(Id == 2){
			$scope.formWaktu = false;
			$scope.formKemampuan = false;
			$scope.formAbsensi = true;
		}else{
			var NilaiAbsen;
			var TotalAbsen = 0;
			if($scope.mData.JumIzin == null || $scope.mData.JumIzin == undefined || $scope.mData.JumIzin == ''){
				$scope.mData.JumIzin = 0;
			}
			if($scope.mData.JumSakit == null || $scope.mData.JumSakit == undefined || $scope.mData.JumSakit == ''){
				$scope.mData.JumSakit = 0; 
			}
			if($scope.mData.JumAlpa == null || $scope.mData.JumAlpa == undefined || $scope.mData.JumAlpa == ''){
				$scope.mData.JumAlpa = 0;
			}
			TotalAbsen = $scope.mData.JumIzin + $scope.mData.JumSakit + $scope.mData.JumAlpa;
			console.log("TotalAbsen",TotalAbsen);
			if(TotalAbsen <= 1){
				NilaiAbsen = 10;
			}else if(TotalAbsen == 2){
				NilaiAbsen = 8;
			}else if(TotalAbsen == 3 || TotalAbsen == 4){
				NilaiAbsen = 6;
			}else if(TotalAbsen == 5 || TotalAbsen == 6){
				NilaiAbsen = 4;
			}else{
				NilaiAbsen = 2;
			}
			console.log("NilaiAbsen",NilaiAbsen);

			Penilaianfactory.saveData(DataSave[0],$scope.mData,NilaiAbsen,$scope.dataKaryawan,combine).then(function(res) {
					
					swal({
						title: 'Penilaian selesai',
						text: "",
						timer: 1000,
						type: 'success',
						showConfirmButton: false
					});
					Penilaianfactory.printGroupAll($scope.dataKaryawan.KaryawanId);

					$scope.getData();
					$scope.mData = {};
					DataSave = [];
					$scope.mainGrid = true;
					$scope.detailForm = false;
			    },
			    function(err) {
			        console.log("err=>", err);
			    }
			);

		}
	}

	$scope.clickRadio = function(value,flag){
		if(flag == 1){
			DataSave[0].WaktuDatang = value;
			console.log("mData.WD",$scope.mData.WD);
		}else if(flag == 2){
			DataSave[0].WaktuPulang = value;
		}else if(flag == 3){
			DataSave[0].WaktuTugas = value;
		}else if(flag == 4){
			DataSave[0].KemampuanMenPek = value;
		}else if(flag == 5){
			DataSave[0].KemampuanMenPekDT = value;
		}else if(flag == 6){
			DataSave[0].KemampuanBT = value;
		}else if(flag == 7){
			DataSave[0].KemampuanBS = value;
		}
		console.log("DataSave",DataSave);
	}

	$scope.dataInit = function(dayFirst,monthFirst,yearFirst,KaryawanId){

		var firstDate = yearFirst + '-' + monthFirst + '-' +  dayFirst;
		
		Penilaianfactory.getDataFilter(firstDate,KaryawanId).then(function(res) {
				$scope.DataPrint = res.data;
				var gajiPastiNaik = 20;
				$scope.persenGaji = (gajiPastiNaik + parseInt($scope.DataPrint[0].NilaiKerjaIndividu) + parseInt($scope.DataPrint[0].NilaiKerjasamaTeam) + parseInt($scope.DataPrint[0].NilaiPekerjaanTpt) + parseInt($scope.DataPrint[0].NilaiPekerjaanTptDt) + parseInt($scope.DataPrint[0].NilaiWaktuDatang) + parseInt($scope.DataPrint[0].NilaiWaktuPulang) + parseInt($scope.DataPrint[0].NilaiWaktuTugas) + parseInt($scope.DataPrint[0].NilaiAbsen))
				console.log("DataPrint",$scope.DataPrint);
				console.log("$scope.persenGaji",$scope.persenGaji);
		    },
		    function(err) {
		        console.log("err=>", err);
		    }
		);
	}
});