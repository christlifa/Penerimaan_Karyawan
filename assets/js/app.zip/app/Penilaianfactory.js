app.factory('Penilaianfactory', function ($http,$httpParamSerializerJQLike,$q,freamwork) {
	var base_url = freamwork.getUrl();
	return{
		
		getDataKaryawan : function(combine){
			return $http.get(base_url + '/Penilaian/getData/'+combine);
		},

		saveData : function(Data,mData,NilaiAbsen,Dk,combine){
			return $http.post(base_url + '/Penilaian/saveData', {
			                      KaryawanId : Dk.KaryawanId,
			                      NilaiWaktuDatang : Data.WaktuDatang,
			                      NilaiWaktuPulang : Data.WaktuPulang,
			                      NilaiWaktuTugas : Data.WaktuTugas,
			                      NilaiPekerjaanTpt : Data.KemampuanMenPek,
			                      NilaiPekerjaanTptDt : Data.KemampuanMenPekDT,
			                      NilaiKerjasamaTeam : Data.KemampuanBT,
			                      NilaiKerjaIndividu : Data.KemampuanBS,
			                      JumlahAlva :mData.JumAlpa,
			                      JumlahIzin : mData.JumIzin,
			                      JumlahSakit : mData.JumSakit,
			                      NilaiAbsen : NilaiAbsen,
			                      Code : combine
			                    });
		},

		printGroupAll : function(KaryawanId){	
			var a = new Date();
			var yearFirst = a.getFullYear();
			var monthFirst = a.getMonth() + 1;
			var dayFirst = a.getDate();

			window.open(base_url + '/Penilaian/printLaporan/'+yearFirst+'/'+monthFirst+'/'+dayFirst+'/'+KaryawanId);
		},


		getDataFilter : function(MualiTgl,KaryawanId){
			return $http.get(base_url + '/Penilaian/getDataFilter/'+MualiTgl+'/'+KaryawanId);
		}
	}

});