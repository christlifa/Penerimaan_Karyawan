app.factory('KaryawanFactory', function ($http,$httpParamSerializerJQLike,$q,freamwork) {
	var base_url = freamwork.getUrl();
	return{
		getDataJK : function(){
			return $http.get(base_url + '/Parameter/getDataJK');
		},


		getDataKaryawan : function(){
			return $http.get(base_url + '/Master/Karyawan/Karyawan/getData');
		},
		
		saveData : function(Data){
			console.log("data save",Data);
			return $http.post(base_url + '/Master/Karyawan/Karyawan/saveData', {
			                      NamaKaryawan : Data.Nama,
			                      Jk : parseInt(Data.Jk),
			                      Alamat : Data.Alamat
			                 });
		},


		deleteData : function(Data){
			return $http.put(base_url + '/Master/Karyawan/Karyawan/deleteData', {
			                      KaryawanId : Data.KaryawanId
			                 });
		},


		updateData : function(Data){
			return $http.put(base_url + '/Master/Karyawan/Karyawan/updateData', {
			                      KaryawanId : Data.ID,
			                      NamaKaryawan : Data.Nama,
			                      Jk : Data.Jk,
			                      Alamat : Data.Alamat
			                 });
		}
	}

});