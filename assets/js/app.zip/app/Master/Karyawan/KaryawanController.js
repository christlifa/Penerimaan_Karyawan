var app = angular.module('app', ['ui.grid', 'ui.grid.pagination','angular-loading-bar']);
app.controller('KaryawanController', function($scope, $http, KaryawanFactory){
	console.log("this karyawan running well");
	$scope.mData = {};
	$scope.mainGrid = true;
	$scope.detailForm = false;


	$scope.getData = function(){

		KaryawanFactory.getDataKaryawan().then(function(res) {
				console.log("Data Karyawan",res.data);
				$scope.gridOptions1.data = res.data;
		    },
		    function(err) {
		        console.log("err=>", err);
		    }
		);
	}

	var actionButton = '<div class="ui-grid-cell-contents">\
	<a href="#"><i class="fa fa-pencil" title="Edit" ng-click="grid.appScope.editData(row.entity)"></i></a>\
	<a href="#"><i class="fa fa-close" title="Delete" style="margin-left:10px;" ng-click="grid.appScope.deleteData(row.entity)"></i></a>\
	</div>';

	

	$scope.gridOptions1 = {
	  paginationPageSizes: [25, 50, 75],
	  paginationPageSize: 25,
	  enableFiltering: true,
	  enableSorting: true,
	  columnDefs: [
	    { name: 'Nama',field:'NamaKaryawan'},
	    { name: 'Jenis Kelamin',field:'JenisKelamin'},
	    { name: 'Alamat',field:'Alamat'},
	    { name: 'Action', cellTemplate: actionButton,  enableFiltering: false}
	  ]
	};

	$scope.TambahButton = function(){
		$scope.mainGrid = false;
		$scope.detailForm = true;

		KaryawanFactory.getDataJK().then(function(res) {
				console.log("Data Jenis Kelamin",res.data);
				$scope.dataJk = res.data;
		    },
		    function(err) {
		        console.log("err=>", err);
		    }
		);
	}

	$scope.KembaliButton = function(){
		$scope.mainGrid = true;
		$scope.detailForm = false;
		$scope.mData = {};
	}

	$scope.simpanButton = function(){
		if($scope.mData.ID == undefined || $scope.mData.ID == null || $scope.mData.ID == ''){

			KaryawanFactory.saveData($scope.mData).then(function(res) {

					swal({
						title: 'Simpan data berhasil',
						text: "",
						timer: 1000,
						type: 'success',
						showConfirmButton: false
					});
					$scope.mainGrid = true;
					$scope.detailForm = false;
					$scope.mData = {};
					$scope.getData();
			    },
			    function(err) {
			        console.log("err=>", err);
			    }
			);
		}else{

			KaryawanFactory.updateData($scope.mData).then(function(res) {

					swal({
						title: 'Ubah data berhasil',
						text: "",
						timer: 1000,
						type: 'success',
						showConfirmButton: false
					});
					$scope.mainGrid = true;
					$scope.detailForm = false;
					$scope.mData = {};
					$scope.getData();
			    },
			    function(err) {
			        console.log("err=>", err);
			    }
			);
		}

	}

	$scope.editData = function(Data){
		console.log("Data",Data);
		$scope.mData.ID = Data.KaryawanId;
		$scope.mData.Nama = Data.NamaKaryawan;
		$scope.mData.Jk = Data.Jk;
		$scope.mData.Alamat = Data.Alamat;
		$scope.TambahButton();
	}

	$scope.deleteData = function(Data){
		console.log("Data dihapus",Data);

		swal({
			title: "Apakah anda yakin untuk menghapus data?",
			text: "",
			type: "warning",
			showCancelButton: true,
			confirmButtonClass: "btn-danger",
			confirmButtonText: "Yes, delete it!",
			closeOnConfirm: false
		},
		function(){

			KaryawanFactory.deleteData(Data).then(function(res) {

					swal({
						title: 'Hapus data berhasil',
						text: "",
						timer: 1000,
						type: 'success',
						showConfirmButton: false
					});
				
					$scope.getData();
			    },
			    function(err) {
			        console.log("err=>", err);
			    }
			);

		});
	}

});