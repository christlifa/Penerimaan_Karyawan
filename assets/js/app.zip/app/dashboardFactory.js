app.factory('dashboardFactory', function ($http,$httpParamSerializerJQLike,$q,freamwork) {
	var base_url =freamwork.getUrl();
	return{
		getDataJK : function(){
			return $http.get(base_url + '/Parameter/getDataJK');
		},
		getDataDashboard : function(){
			return $http.get(base_url + '/Master/Karyawan/Karyawan/getDataDashboard');
		},
	}

});